document.getElementById('submit').addEventListener('click', function() {
    const selectedFolders = [];
    for (let i = 1; i <= 5; i++) {
        if (document.getElementById(`num${i}`).checked) {
            selectedFolders.push(i);
        }
    }

    const keyword = document.getElementById('dropdown').value;
    fetchText(selectedFolders, keyword);
});

function fetchText(folders, keyword) {
    fetch('getText.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ folders, keyword })
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('outputText').value = data;
    })
    .catch(error => console.error('Error:', error));
}

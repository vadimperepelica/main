<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$data = json_decode(file_get_contents('php://input'), true);
$folders = $data['folders'];
$keyword = $data['keyword'];
$texts = [];


foreach ($folders as $folder) {
    $folderPath = __DIR__ . "/text/$folder/$keyword";
    if (is_dir($folderPath)) {
        $files = array_diff(scandir($folderPath), array('..', '.'));
        if (count($files) > 0) {
            $randomFile = $files[array_rand($files)];
            $filePath = "$folderPath/$randomFile";
            if (file_exists($filePath) && is_readable($filePath)) {
                $fileContent = file_get_contents($filePath);
                // Разделение текста по разделителю и выбор случайного фрагмента
                $fileTexts = explode("-----", $fileContent);
                $randomText = $fileTexts[array_rand($fileTexts)];
                array_push($texts, $randomText);
            }
        }
    }
}

echo implode("\n", $texts);
}
?>
window.addEventListener("load", () => {
  const e = document.getElementById("wheel__button"),
    s = document.getElementById("wheel__spinner"),
    t = document.getElementById("popup"),
    a = document.getElementById("popup__window_1"),
    d = document.getElementById("popup__window_2"),
    l = document.getElementById("popup__button"),
    i = document.getElementById("game__wheel"),
    o = document.getElementById("game__cards"),
    n = document.getElementsByClassName("card"),
    _ = document.getElementById("bonuses-page"),
    c = document.getElementById("bonus-2"),
    r = s.getAttribute("data-path");
  e.addEventListener("click", () => {
    (e.disabled = !0),
      s.classList.remove("wheel__spinner_animated"),
      s.classList.add("wheel__spinner_win"),
      setTimeout(function () {
        (localStorage.spin = "19010_spin"),
          t.classList.add("popup__show"),
          a.classList.add("popup__window_show"),
          _.classList.remove("bonuses__hidden");
      }, 4e3);
  }),
    l.addEventListener("click", () => {
      t.classList.remove("popup__show"),
        a.classList.remove("popup__window_show"),
        i.classList.add("game__hidden"),
        o.classList.remove("game__hidden"),
        (localStorage.gameCards = "19010_game2_start");
    });
  let m = 0;
  for (let a = 0; a < n.length; a++)
    n[a].addEventListener("click", () => {
      if (0 == m) {
        n[a].classList.add("card__animation"),
          (n[a].getElementsByClassName("card__action")[0].src =
            r + "/card-animation.gif?a=" + m),
          (localStorage.cards_win1_19010 = n[a].getAttribute("data-attr")),
          (localStorage.gameCards = "19010_game2_card1"),
          m++;
        for (let e = 0; e < n.length; e++)
          e !== a &&
            (n[e].classList.add("card__disabled"),
            setTimeout(function () {
              n[e].classList.remove("card__disabled");
            }, 1100));
      } else if (1 == m) {
        n[a].classList.add("card__animation"),
          (n[a].getElementsByClassName("card__action")[0].src =
            r + "/card-animation.gif?a=" + m),
          (localStorage.cards_win2_19010 = n[a].getAttribute("data-attr")),
          (localStorage.gameCards = "19010_game2_card2");
        for (let e = 0; e < n.length; e++)
          e !== a && n[e].classList.add("card__disabled");
        setTimeout(function () {
          (localStorage.currentSpin = "HTMLC_1174_mbs_spin"),
            t.classList.add("popup__show"),
            d.classList.add("popup__window_show"),
            c.classList.remove("bonus__hidden");
        }, 2e3);
      }
    });
  for (
    var g = $("html"),
      p = $(".preloader"),
      u = $(".curr_lang"),
      h = localStorage.lang,
      w = new URLSearchParams(window.location.search).get("lang"),
      L = ["pt", "tr", "es"],
      f = 0,
      v = 0;
    v < L.length;
    v++
  )
    if (h === L[v] || w === L[v]) {
      for (j = 0; j < L.length; j++) g.removeClass(L[j]);
      g.addClass(L[v]), (h = L[v]);
    }
  for (v = 0; v < L.length; v++) h === L[v] && (f = 1);
  0 === f && (g.addClass("pt"), (h = "pt")),
    L.forEach(function (e) {
      g.removeClass(e).addClass(h);
    }),
    $('.lang_list_item[data-lang="' + h + '"]')
      .addClass("curr")
      .siblings()
      .removeClass("curr"),
    u.html($('.lang_list_item[data-lang="' + h + '"]').html()),
    setTimeout(function () {
      p.fadeOut(),
        setTimeout(function () {
          g.addClass("hide");
        }, 200);
    }, 200);
  var C = $(".lang_switcher"),
    b = $(".lang_list"),
    E = $(".lang_list_item");
  if (
    (C.click(function () {
      b.toggleClass("act");
    }),
    (s.src = r + "/wheel-" + h + ".png"),
    E.click(function () {
      p.fadeIn(),
        g.removeClass("hide"),
        setTimeout(function () {
          p.fadeOut(), g.addClass("hide");
        }, 200);
      var e = $(this).data("lang"),
        a = $(".lang_list_item")
          .map(function (e, a) {
            return $(a).data("lang");
          })
          .toArray()
          .join(" ");
      g.removeClass(a).addClass(e),
        (localStorage.lang = e),
        $('.lang_list_item[data-lang="' + e + '"]')
          .addClass("curr")
          .siblings()
          .removeClass("curr"),
        u.html($(this).html()),
        (s.src = r + "/wheel-" + e + ".png");
    }),
    $(document).mouseup(function (e) {
      C.is(e.target) || 0 !== C.has(e.target).length || b.removeClass("act");
    }),
    "19010_spin" == localStorage.spin &&
      ((e.disabled = !0),
      s.classList.remove("wheel__spinner_animated"),
      s.classList.add("wheel__spinner_final"),
      t.classList.add("popup__show"),
      a.classList.add("popup__window_show"),
      _.classList.remove("bonuses__hidden")),
    localStorage.gameCards)
  ) {
    switch (localStorage.gameCards) {
      case "19010_game2_start":
        t.classList.add("popup__show"),
          a.classList.add("popup__window_show"),
          i.classList.add("game__hidden"),
          o.classList.remove("game__hidden");
        break;
      case "19010_game2_card1":
        t.classList.remove("popup__show"),
          a.classList.remove("popup__window_show"),
          i.classList.add("game__hidden"),
          o.classList.remove("game__hidden");
        break;
      case "19010_game2_card2":
        t.classList.remove("popup__show"),
          a.classList.remove("popup__window_show"),
          i.classList.add("game__hidden"),
          o.classList.remove("game__hidden"),
          t.classList.add("popup__show"),
          d.classList.add("popup__window_show"),
          c.classList.remove("bonus__hidden");
    }
    for (let e = 0; e < n.length; e++)
      if (
        (localStorage.cards_win1_19010 == n[e].getAttribute("data-attr") &&
          (n[e].classList.add("card__win"), (m = 1)),
        localStorage.cards_win2_19010 == n[e].getAttribute("data-attr"))
      ) {
        n[e].classList.add("card__win"), (m = 2);
        for (let e = 0; e < n.length; e++) n[e].classList.add("card__disabled");
      }
  }
});
